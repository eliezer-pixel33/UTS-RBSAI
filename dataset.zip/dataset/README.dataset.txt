# plant detection > 2025-10-27 4:28pm
https://universe.roboflow.com/tumor-zi554/plant-detection-xjiqv

Provided by a Roboflow user
License: CC BY 4.0

